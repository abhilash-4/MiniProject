from django.apps import AppConfig


class TrainConfig(AppConfig):
    name = 'train'
